const express = require('express')
const app = express()
const mongoose = require('mongoose');



app.get('/',(req,res)=>{
    res.send("hello form the world")
})
mongoose.connect('mongodb+srv://2627971:k5e6fbsABw6fanyo@cluster0.kijv2.mongodb.net/Mytodolist?retryWrites=true&w=majority&appName=Cluster0')
  .then(() => {
    console.log('Connected!')
    app.listen(3000,()=>{
        console.log("sever listing on port 3000")
    })
});